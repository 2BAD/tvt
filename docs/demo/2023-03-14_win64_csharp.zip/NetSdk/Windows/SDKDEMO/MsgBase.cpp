#include "StdAfx.h"
#include "MsgBase.h"


CMsgBase::CMsgBase(void)
{
}

CMsgBase::~CMsgBase(void)
{

}

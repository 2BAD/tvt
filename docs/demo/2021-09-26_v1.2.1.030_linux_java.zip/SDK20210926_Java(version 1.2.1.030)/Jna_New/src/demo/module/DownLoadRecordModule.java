package demo.module;

import netsdk.lib.DeviceSdk;
import netsdk.lib.ToolKits;
import netsdk.struct.DD_TIME;

import com.sun.jna.NativeLong;
import com.sun.jna.ptr.IntByReference;

/**
 * 下载录像接口实现
 * 主要有 ： 查询录像、下载录像、设置码流类型功能
 */
public class DownLoadRecordModule {
	// 下载句柄
	//public static LLong m_hDownLoadHandle = new LLong(0);
	
	// 查找录像文件
	public static boolean queryRecordFile(NativeLong nChannelId, DD_TIME.ByReference stTimeStart, DD_TIME.ByReference stTimeEnd) {
		NativeLong fileHandle = LoginModule.netsdk.NET_SDK_FindFile(LoginModule.m_hLoginHandle, nChannelId.intValue(), stTimeStart,stTimeEnd);		
		if(fileHandle.longValue() > 0) {
			
			return true;
		}
		return false;
	}
	
	/**
	 *  设置回放时的码流类型
	 * @param m_streamType 码流类型
	 */
//	public static void setStreamType(int m_streamType) {
//        
//        IntByReference steamType = new IntByReference(m_streamType);// 0-主辅码流,1-主码流,2-辅码流
//        int emType = NetSDKLib.EM_USEDEV_MODE.NET_RECORD_STREAM_TYPE;       
//
//        boolean bret = LoginModule.netsdk.CLIENT_SetDeviceMode(LoginModule.m_hLoginHandle, emType, steamType.getPointer());
//        if (!bret) {
//        	System.err.println("Set Stream Type Failed, Get last error." + ToolKits.getErrorCodePrint());
//        } else {
//        	System.out.println("Set Stream Type  Succeed!");
//        }
//	}
	
//	public static LLong downloadRecordFile(int nChannelId,    
//										     int nRecordFileType,
//										     NetSDKLib.NET_TIME stTimeStart, 
//										     NetSDKLib.NET_TIME stTimeEnd, 
//										     String SavedFileName,
//										     NetSDKLib.fTimeDownLoadPosCallBack cbTimeDownLoadPos) {
//		
//		m_hDownLoadHandle = LoginModule.netsdk.CLIENT_DownloadByTimeEx(LoginModule.m_hLoginHandle, nChannelId, nRecordFileType, 
//															stTimeStart, stTimeEnd, SavedFileName, 
//															cbTimeDownLoadPos, null, null, null, null);
//		if(m_hDownLoadHandle.longValue() != 0) {
//			System.out.println("Downloading RecordFile!");
//		} else {
//			System.err.println("Download RecordFile Failed!" + ToolKits.getErrorCodePrint());
//		}
//		return m_hDownLoadHandle;
//	}
	
//	public static void stopDownLoadRecordFile(LLong m_hDownLoadHandle) {
//		if (m_hDownLoadHandle.longValue() == 0) {		
//			return;
//		}
//		LoginModule.netsdk.CLIENT_StopDownload(m_hDownLoadHandle);
//	}
}

package demo.common;

public interface DeviceManagerListener {
	void onDeviceManager(String deviceId, String username, String password);
}

package demo.common;

import java.util.HashMap;
import java.util.Map;

import netsdk.struct.*;

public class LocalData {

	public static Map<Integer, NET_SDK_FACE_INFO_GROUP_ITEM> faceGroup = new HashMap<Integer, NET_SDK_FACE_INFO_GROUP_ITEM>();
	public static Map<Integer, NET_SDK_FACE_INFO_LIST_ITEM> faceList = new HashMap<Integer, NET_SDK_FACE_INFO_LIST_ITEM>();
	public static Map<Integer,NET_SDK_IVE_FACE_MATCH_QUERY_ALBUM_REPLY_INFO> IPCFaceList = 
			new HashMap<Integer,NET_SDK_IVE_FACE_MATCH_QUERY_ALBUM_REPLY_INFO>();
	public LocalData() {
		// TODO Auto-generated constructor stub
		
		
	}

}

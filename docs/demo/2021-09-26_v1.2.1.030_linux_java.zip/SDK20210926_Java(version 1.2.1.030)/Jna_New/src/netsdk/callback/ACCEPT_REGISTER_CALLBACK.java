package netsdk.callback;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;

import netsdk.struct.LPNET_SDK_DEVICEINFO;

import com.sun.jna.Callback;

public interface ACCEPT_REGISTER_CALLBACK extends Callback  {
	public void invoke(NativeLong lUserID, NativeLong lRegisterID, LPNET_SDK_DEVICEINFO.ByReference pDeviceInfo,
			Pointer pUser);
}

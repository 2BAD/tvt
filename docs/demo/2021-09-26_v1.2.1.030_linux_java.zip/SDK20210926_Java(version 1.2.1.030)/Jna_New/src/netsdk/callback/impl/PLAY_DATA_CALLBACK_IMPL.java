package netsdk.callback.impl;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;

import netsdk.callback.PLAY_DATA_CALLBACK;
import netsdk.struct.NET_SDK_FRAME_INFO;

public class PLAY_DATA_CALLBACK_IMPL implements PLAY_DATA_CALLBACK{
	public void invoke(NativeLong lLiveHandle,NET_SDK_FRAME_INFO frameInfo,Pointer pBuffer, Pointer pUser) {
		
	}
}

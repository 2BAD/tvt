package netsdk.callback.impl;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;

import netsdk.callback.BACKUP_DATA_CALLBACK;

public class BACKUP_DATA_CALLBACK_IMPL implements BACKUP_DATA_CALLBACK {
	@Override
	public void invoke(NativeLong lFileHandle, int dataType, Pointer pBuffer, int dataLen, Pointer pUser) {
		System.out.println("BACKUP_DATA_CALLBACK_IMPL  回调方法执行");
	}
}

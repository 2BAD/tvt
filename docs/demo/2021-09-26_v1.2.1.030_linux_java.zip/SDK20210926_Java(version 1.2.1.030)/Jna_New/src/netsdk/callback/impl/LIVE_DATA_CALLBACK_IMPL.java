package netsdk.callback.impl;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;

import netsdk.callback.LIVE_DATA_CALLBACK;

public class LIVE_DATA_CALLBACK_IMPL implements LIVE_DATA_CALLBACK {
	@Override
	//NET_SDK_FRAME_INFO 结构体为 回调函数参数
	public void invoke(NativeLong lLiveHandle, Pointer frameInfo, Pointer pBuffer, Pointer pUser) {

		System.out.println("实时预览回调被方法执行");
		System.out.println("lLiveHandle："+lLiveHandle);
		//NET_SDK_FRAME_INFO info = new NET_SDK_FRAME_INFO(frameInfo);
		
	}
}

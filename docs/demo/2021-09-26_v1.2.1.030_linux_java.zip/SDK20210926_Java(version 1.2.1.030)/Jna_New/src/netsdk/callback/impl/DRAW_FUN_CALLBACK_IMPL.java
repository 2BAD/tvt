package netsdk.callback.impl;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;

import netsdk.callback.DRAW_FUN_CALLBACK;

public class DRAW_FUN_CALLBACK_IMPL implements DRAW_FUN_CALLBACK {
	@Override
	public void invoke(NativeLong lLiveHandle, Pointer hDC, Pointer pUser) {
		System.out.println("DRAW_FUN_CALLBACK_IMPL 回调方法被执行");
	}
}

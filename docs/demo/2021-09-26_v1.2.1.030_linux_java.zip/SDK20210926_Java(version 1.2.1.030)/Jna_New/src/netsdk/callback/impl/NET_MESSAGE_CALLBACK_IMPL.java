package netsdk.callback.impl;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;

import netsdk.callback.NET_MESSAGE_CALLBACK;

public class NET_MESSAGE_CALLBACK_IMPL implements NET_MESSAGE_CALLBACK {
	@Override
	public boolean invoke(NativeLong lCommand, NativeLong lUserID, Pointer pBuf, int dwBufLen, Pointer pUser) {
		
		//当lCommand取值为NET_SDK_ALARM时，pBuf为NET_SDK_ALARMINFO结构体的数组； 当lCommand取值为NET_SDK_RECORD时，pBuf为NET_SDK_RECORD_STATUS结构体的数组 
		System.out.println("NET_MESSAGE_CALLBACK_IMPL 回调被方法执行");
		System.out.println("lCommand：" + lCommand);
		return true;
	}
}

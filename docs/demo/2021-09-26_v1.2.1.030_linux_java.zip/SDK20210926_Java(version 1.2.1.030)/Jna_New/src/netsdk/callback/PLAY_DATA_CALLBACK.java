package netsdk.callback;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;

import netsdk.struct.NET_SDK_FRAME_INFO;

import com.sun.jna.Callback;

public interface PLAY_DATA_CALLBACK extends Callback{
	public void invoke(NativeLong lLiveHandle,NET_SDK_FRAME_INFO frameInfo,Pointer pBuffer, Pointer pUser);

}

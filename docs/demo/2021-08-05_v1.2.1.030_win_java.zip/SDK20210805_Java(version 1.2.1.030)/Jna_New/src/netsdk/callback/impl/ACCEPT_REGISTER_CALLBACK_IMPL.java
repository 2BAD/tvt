package netsdk.callback.impl;

import java.io.UnsupportedEncodingException;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;

import netsdk.callback.ACCEPT_REGISTER_CALLBACK;
import netsdk.struct.LPNET_SDK_DEVICEINFO.ByReference;

public class ACCEPT_REGISTER_CALLBACK_IMPL implements ACCEPT_REGISTER_CALLBACK {
	@Override
	public void invoke(NativeLong lUserID, NativeLong lRegisterID, ByReference pDeviceInfo, Pointer pUser) {
		System.out.println("device connected:" + lRegisterID);
		try {
			String name = new String(pDeviceInfo.deviceName, "GB2312");
			System.out.println("设备名称是：" + name);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}

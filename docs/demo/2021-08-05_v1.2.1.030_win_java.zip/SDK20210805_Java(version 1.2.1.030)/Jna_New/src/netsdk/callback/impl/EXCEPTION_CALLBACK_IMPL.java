package netsdk.callback.impl;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;

import netsdk.callback.EXCEPTION_CALLBACK;

public class EXCEPTION_CALLBACK_IMPL implements EXCEPTION_CALLBACK {
	@Override
	public void invoke(int dwType, NativeLong lUserID, NativeLong lHandle, Pointer pUser) {
		System.out.println("EXCEPTION_CALLBACK_IMPL  回调方法执行");
	}
}

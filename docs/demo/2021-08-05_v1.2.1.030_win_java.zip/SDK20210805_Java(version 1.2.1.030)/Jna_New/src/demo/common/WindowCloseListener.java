package demo.common;

public interface WindowCloseListener {
	void windowClosing();
}

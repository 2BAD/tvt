/***********************************************************************
** Copyright (C) Tongwei Video Technology Co.,Ltd. All rights reserved.
** Author       :	Ԭʯά
** Date         : 2010-12-31
** Name         : DDCommon.h
** Version      : 1.0
** Description  :
** Modify Record:
***********************************************************************/

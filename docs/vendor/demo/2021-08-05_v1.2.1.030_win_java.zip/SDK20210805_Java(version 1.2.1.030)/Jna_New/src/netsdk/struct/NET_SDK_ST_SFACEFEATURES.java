﻿package netsdk.struct;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

public class NET_SDK_ST_SFACEFEATURES extends Structure {
	public NET_SDK_ST_SFACEFEATURES(Pointer p) {
		super(p,ALIGN_NONE);
		useMemory(p);
		read();
	}
	public NET_SDK_ST_SFACEFEATURES() {
		super(ALIGN_NONE);
	}

	public static class ByReference extends NET_SDK_ST_SFACEFEATURES implements Structure.ByReference {
	}

	public static class ByValue extends NET_SDK_ST_SFACEFEATURES implements Structure.ByValue {
	}

    public int itemId;	//目标id

	@Override
	protected List<String> getFieldOrder() {
		List<Field> flist = getFieldList();
		List<String> list = new ArrayList<>(flist.size());
		for (Field f : flist) {
		    list.add(f.getName());
		}
		return list;
	}
}
package netsdk.callback;

import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Callback;

public interface EXCEPTION_CALLBACK extends Callback  {
	public void invoke(int dwType, NativeLong lUserID, NativeLong lHandle, Pointer pUser);
}

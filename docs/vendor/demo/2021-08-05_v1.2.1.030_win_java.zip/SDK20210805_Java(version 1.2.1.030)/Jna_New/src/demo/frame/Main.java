package demo.frame;

import javax.swing.SwingUtilities;

import demo.common.SwitchLanguage;
import netsdk.lib.DeviceSdk;
public class Main {  
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				if(DeviceSdk.INSTANCE != null) {
					System.setProperty("java.awt.im.style", "on-the-spot"); // 去除中文输入弹出框
					SwitchLanguage demo = new SwitchLanguage();
					demo.setVisible(true);
				}
			}
		});	
//		String dataStr = "\\u8f66\\u724c\\u8bc6\\u522b";
//		System.out.println(decodeUnicode(dataStr));
//		String str = "IPC人脸识别";
//		gbEncoding(str); 
	}
	//中文转Unicode
   public static String gbEncoding(final String gbString) {   //gbString = "测试"
       char[] utfBytes = gbString.toCharArray();   //utfBytes = [测, 试]
       String unicodeBytes = "";   
       for (int byteIndex = 0; byteIndex < utfBytes.length; byteIndex++) {   
           String hexB = Integer.toHexString(utfBytes[byteIndex]);   //转换为16进制整型字符串
             if (hexB.length() <= 2) {   
                 hexB = "00" + hexB;   
            }   
            unicodeBytes = unicodeBytes + "\\u" + hexB;   
       }   
       System.out.println( gbString + "'s unicodeBytes is: " + unicodeBytes);   
       return unicodeBytes;   
   }
 //Unicode转中文
  public static String decodeUnicode(final String dataStr) {   
     int start = 0;   
     int end = 0;   
     final StringBuffer buffer = new StringBuffer();   
     while (start > -1) {   
         end = dataStr.indexOf("\\u", start + 2);   
         String charStr = "";   
         if (end == -1) {   
            charStr = dataStr.substring(start + 2, dataStr.length());   
        } else {   
            charStr = dataStr.substring(start + 2, end);   
        }   
        char letter = (char) Integer.parseInt(charStr, 16); // 16进制parse整形字符串。   
        buffer.append(new Character(letter).toString());   
        start = end;   
    }   
    return buffer.toString();   
 }


}

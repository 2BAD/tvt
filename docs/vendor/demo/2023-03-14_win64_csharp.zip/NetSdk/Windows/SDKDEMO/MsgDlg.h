#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CMsgDlg �Ի���

class CMsgDlg : public CDialog
{
	DECLARE_DYNAMIC(CMsgDlg)

public:
	CMsgDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMsgDlg();

// �Ի�������
	enum { IDD = IDD_MSG_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg LRESULT OnRecieveMsg(WPARAM wparam, LPARAM lparam);
	afx_msg void OnBnClickedButtonMsgClear();
public:
	CListCtrl m_msgList;
};

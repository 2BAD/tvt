// ConnectModeDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SDKDEMO.h"
#include "ConnectModeDlg.h"


// CConnectModeDlg �Ի���

IMPLEMENT_DYNAMIC(CConnectModeDlg, CDialog)

CConnectModeDlg::CConnectModeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConnectModeDlg::IDD, pParent)
	, m_registerPort(2009)
	, m_connectMode(0)
{

}

CConnectModeDlg::~CConnectModeDlg()
{
}

void CConnectModeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_PORT, m_registerPort);
	DDV_MinMaxUInt(pDX, m_registerPort, 1, 65535);
	DDX_Radio(pDX, IDC_RADIO_LOGIN, m_connectMode);
}


BEGIN_MESSAGE_MAP(CConnectModeDlg, CDialog)
	ON_BN_CLICKED(IDC_RADIO_LOGIN, &CConnectModeDlg::OnBnClickedRadioLogin)
	ON_BN_CLICKED(IDC_RADIO_AUTO, &CConnectModeDlg::OnBnClickedRadioAuto)
END_MESSAGE_MAP()


// CConnectModeDlg ��Ϣ��������

BOOL CConnectModeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	GetDlgItem(IDC_STC_PORT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_PORT)->ShowWindow(SW_HIDE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CConnectModeDlg::OnBnClickedRadioLogin()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	GetDlgItem(IDC_STC_PORT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_PORT)->ShowWindow(SW_HIDE);
}

void CConnectModeDlg::OnBnClickedRadioAuto()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	GetDlgItem(IDC_STC_PORT)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_EDIT_PORT)->ShowWindow(SW_SHOW);
}

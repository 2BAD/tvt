#pragma once


// CConnectModeDlg �Ի���

class CConnectModeDlg : public CDialog
{
	DECLARE_DYNAMIC(CConnectModeDlg)

public:
	CConnectModeDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CConnectModeDlg();

// �Ի�������
	enum { IDD = IDD_CONNECT_MODE };
	enum 
	{
		CONNECT_MODE_LOGIN_TO_DEVICE,
		CONNECT_MODE_REGISTER_TO_CENTER,
	};

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
	afx_msg void OnBnClickedRadioLogin();
	afx_msg void OnBnClickedRadioAuto();
	
public:
	UINT m_registerPort;
	int m_connectMode;
};
